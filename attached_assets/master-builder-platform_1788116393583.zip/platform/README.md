# Master Builder Platform — Deployment Guide (Replit)

This is a real backend application: accounts, a database, gated course
content, auto-graded module quizzes, a final exam, and PDF certificates
on completion.

## What's included
- `server.js` — Express backend (auth, database, quiz grading, certificate PDF)
- `public/index.html` — the frontend (login, course, quizzes, exam)
- `data/modules.json` — all 22 modules' content
- `data/quiz_data.json` — 88 auto-graded quiz questions (4 per module)
- `data/final_exam.json` — 22-question final exam
- `data/app.db` — SQLite database (created automatically on first run)

## Deploy to Replit — step by step

1. **Create a new Repl** → choose "Import from ZIP" (or "Node.js" template,
   then drag these files in) and upload everything in this folder.

2. **Install dependencies.** Replit usually does this automatically when
   it detects `package.json`. If not, open the Shell tab and run:
   ```
   npm install
   ```

3. **Set your environment secrets.** In Replit, open the "Secrets" tool
   (lock icon in the sidebar) and add:
   - `SESSION_SECRET` — any long random string (keeps login sessions secure)
   - `ACCESS_CODE` — a code you give buyers so they can unlock the course
     right after purchase (see payment flow below)
   - `ADMIN_SECRET` — a password only you know, used to manually grant
     access to a specific buyer's email if needed

4. **Run it.** Click the Run button (or `npm start` in the Shell). Replit
   will give you a live URL like `yourapp.username.repl.co`.

5. **Click "Deploy"** (top right in Replit) to keep it running persistently
   with a stable URL, rather than only while your browser tab is open.

## How payment currently works (simple version)

Right now, access is unlocked with a single shared `ACCESS_CODE` you set
in Secrets. Flow:

1. Sell the course on Gumroad/Stripe as before (a simple checkout link).
2. In your Gumroad product's "content" or automatic email, include the
   `ACCESS_CODE` you set above.
3. Buyer signs up on your Replit app and enters that code — this unlocks
   `paid = 1` on their account.

This is simple but has a real limitation: **the same code works for
everyone**, so if it leaks, anyone can unlock the course for free. It's
fine to start with, but you'll want to upgrade it once you have real sales
volume.

### Upgrading to real per-purchase access (recommended before scaling)

Two solid options, in order of effort:

**A. Manual grant (no code changes needed)** — after each sale, call:
```
POST /api/admin/grant
{ "adminSecret": "<your ADMIN_SECRET>", "email": "buyer@email.com" }
```
You can do this from any tool that sends a POST request (Postman, curl,
or a simple Zapier/Make automation triggered by a Gumroad sale webhook).
This is realistic for lower sales volume without writing any new code.

**B. Real Stripe integration (fully automatic)** — replace the manual
grant with a Stripe Checkout session + webhook that calls the same
database update automatically when a payment succeeds. This requires a
Stripe account and roughly 30-40 lines of additional code in `server.js`
(a `/api/create-checkout-session` route and a `/api/stripe-webhook`
route). Ask me to build this in whenever you're ready — I kept the
`requirePaid` gate structured so this drops in without touching anything
else.

## How the course logic works

- Module 1 is always unlocked. Each subsequent module unlocks only after
  the previous module's quiz is passed (75% or higher).
- Each module has 4 multiple-choice questions drawn from real module
  content, with distractor answers pulled from other modules.
- Once all 22 module quizzes are passed, the Final Exam (22 questions,
  75% to pass) becomes available.
- Passing the final exam generates a certificate: a unique ID, a
  downloadable PDF (`/api/certificate/:id`), and a public verification
  page (`/verify/:id`) anyone can check.

## Database note

This uses SQLite (`data/app.db`), a single file — simple and reliable
for a course-sized user base. On Replit, this file persists across
restarts as long as you don't delete/reset the Repl. If you outgrow
SQLite (thousands of concurrent users), migrating to Postgres is a
moderate-effort follow-up — ask me when you're there.

## Local testing (optional, before deploying)

```
npm install
SESSION_SECRET=test ACCESS_CODE=TESTCODE123 ADMIN_SECRET=admin123 npm start
```
Then open `http://localhost:3000`.
