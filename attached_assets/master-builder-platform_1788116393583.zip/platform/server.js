const express = require('express');
const session = require('express-session');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const PDFDocument = require('pdfkit');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// ---------- Database ----------
const db = new Database(path.join(__dirname, 'data', 'app.db'));
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  paid INTEGER DEFAULT 0,
  track TEXT DEFAULT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS progress (
  user_id TEXT NOT NULL,
  module_num INTEGER NOT NULL,
  quiz_passed INTEGER DEFAULT 0,
  quiz_score INTEGER DEFAULT 0,
  completed_at TEXT DEFAULT NULL,
  PRIMARY KEY (user_id, module_num)
);
CREATE TABLE IF NOT EXISTS certificates (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  final_score INTEGER NOT NULL,
  issued_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

// ---------- Course data ----------
const MODULES = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'modules.json')));
const QUIZ_DATA = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'quiz_data.json')));
const FINAL_EXAM = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'final_exam.json')));
const MODULE_ORDER = MODULES.map(m => m.num); // sequence gate
const PASS_THRESHOLD = 0.75; // 75% to pass a module quiz
const FINAL_PASS_THRESHOLD = 0.75;

// ---------- Middleware ----------
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'change-this-secret-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 30 } // 30 days
}));

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
  next();
}
function requirePaid(req, res, next) {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.userId);
  if (!user || !user.paid) return res.status(403).json({ error: 'Purchase required' });
  next();
}

// ---------- Auth routes ----------
app.post('/api/signup', (req, res) => {
  const { name, email, password, accessCode } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'Missing fields' });
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase());
  if (existing) return res.status(400).json({ error: 'Account already exists' });

  const id = uuidv4();
  const hash = bcrypt.hashSync(password, 10);
  // ACCESS_CODE env var lets you manually grant paid access (e.g., after a Gumroad/Stripe sale)
  // until you wire up a real payment webhook. See README for Stripe webhook integration point.
  const paid = (accessCode && accessCode === process.env.ACCESS_CODE) ? 1 : 0;
  db.prepare('INSERT INTO users (id, name, email, password_hash, paid) VALUES (?,?,?,?,?)')
    .run(id, name, email.toLowerCase(), hash, paid);
  req.session.userId = id;
  res.json({ ok: true, paid: !!paid });
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get((email||'').toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  req.session.userId = user.id;
  res.json({ ok: true, paid: !!user.paid });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/me', (req, res) => {
  if (!req.session.userId) return res.json({ loggedIn: false });
  const user = db.prepare('SELECT id, name, email, paid, track FROM users WHERE id = ?').get(req.session.userId);
  if (!user) return res.json({ loggedIn: false });
  const progress = db.prepare('SELECT module_num, quiz_passed, quiz_score FROM progress WHERE user_id = ?').all(user.id);
  const cert = db.prepare('SELECT id, final_score, issued_at FROM certificates WHERE user_id = ?').get(user.id);
  res.json({ loggedIn: true, user, progress, certificate: cert || null });
});

app.post('/api/track', requireAuth, (req, res) => {
  const { track } = req.body;
  db.prepare('UPDATE users SET track = ? WHERE id = ?').run(track, req.session.userId);
  res.json({ ok: true });
});

// ---------- Admin: manually grant paid access ----------
// Simple manual-grant endpoint for use right after a Gumroad/Stripe sale notification,
// protected by an admin secret. Replace with a real Stripe webhook when ready (see README).
app.post('/api/admin/grant', (req, res) => {
  const { adminSecret, email } = req.body;
  if (!process.env.ADMIN_SECRET || adminSecret !== process.env.ADMIN_SECRET) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const result = db.prepare('UPDATE users SET paid = 1 WHERE email = ?').run((email||'').toLowerCase());
  res.json({ ok: true, updated: result.changes });
});

// ---------- Course content (gated) ----------
app.get('/api/modules', requireAuth, requirePaid, (req, res) => {
  // Return module list without full content (for the module list screen)
  const list = MODULES.map(m => ({ num: m.num, title: m.title, phaseNum: m.phaseNum, phaseName: m.phaseName, targetAudience: m.targetAudience }));
  res.json({ modules: list });
});

app.get('/api/modules/:num', requireAuth, requirePaid, (req, res) => {
  const num = parseInt(req.params.num, 10);
  // sequential gate: module N requires module N-1's quiz passed (module 1 always open)
  const idx = MODULE_ORDER.indexOf(num);
  if (idx > 0) {
    const prevNum = MODULE_ORDER[idx - 1];
    const prevProgress = db.prepare('SELECT quiz_passed FROM progress WHERE user_id = ? AND module_num = ?')
      .get(req.session.userId, prevNum);
    if (!prevProgress || !prevProgress.quiz_passed) {
      return res.status(403).json({ error: 'Previous module quiz not yet passed', locked: true, requiredModule: prevNum });
    }
  }
  const mod = MODULES.find(m => m.num === num);
  if (!mod) return res.status(404).json({ error: 'Not found' });
  res.json({ module: mod });
});

app.get('/api/quiz/:num', requireAuth, requirePaid, (req, res) => {
  const num = req.params.num;
  const questions = QUIZ_DATA[num];
  if (!questions) return res.status(404).json({ error: 'No quiz for this module' });
  // strip correct answer index before sending
  const safe = questions.map(q => ({ q: q.q, options: q.options }));
  res.json({ questions: safe });
});

app.post('/api/quiz/:num/submit', requireAuth, requirePaid, (req, res) => {
  const num = req.params.num;
  const numInt = parseInt(num, 10);
  const questions = QUIZ_DATA[num];
  if (!questions) return res.status(404).json({ error: 'No quiz for this module' });
  const { answers } = req.body; // array of selected option indices
  if (!Array.isArray(answers) || answers.length !== questions.length) {
    return res.status(400).json({ error: 'Invalid answers' });
  }
  let correctCount = 0;
  questions.forEach((q, i) => { if (answers[i] === q.correct) correctCount++; });
  const score = Math.round((correctCount / questions.length) * 100);
  const passed = (correctCount / questions.length) >= PASS_THRESHOLD ? 1 : 0;

  db.prepare(`
    INSERT INTO progress (user_id, module_num, quiz_passed, quiz_score, completed_at)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(user_id, module_num) DO UPDATE SET
      quiz_passed = MAX(quiz_passed, excluded.quiz_passed),
      quiz_score = excluded.quiz_score,
      completed_at = excluded.completed_at
  `).run(req.session.userId, numInt, passed, score, passed ? new Date().toISOString() : null);

  res.json({ score, passed, correctCount, total: questions.length });
});

// ---------- Final exam ----------
app.get('/api/final-exam', requireAuth, requirePaid, (req, res) => {
  // require all 22 module quizzes passed first
  const passedCount = db.prepare('SELECT COUNT(*) as c FROM progress WHERE user_id = ? AND quiz_passed = 1')
    .get(req.session.userId).c;
  if (passedCount < MODULE_ORDER.length) {
    return res.status(403).json({ error: 'Complete all module quizzes first', locked: true, passedCount, required: MODULE_ORDER.length });
  }
  const safe = FINAL_EXAM.map(q => ({ q: q.q, options: q.options, module: q.module }));
  res.json({ questions: safe });
});

app.post('/api/final-exam/submit', requireAuth, requirePaid, (req, res) => {
  const { answers, name } = req.body;
  if (!Array.isArray(answers) || answers.length !== FINAL_EXAM.length) {
    return res.status(400).json({ error: 'Invalid answers' });
  }
  let correctCount = 0;
  FINAL_EXAM.forEach((q, i) => { if (answers[i] === q.correct) correctCount++; });
  const score = Math.round((correctCount / FINAL_EXAM.length) * 100);
  const passed = (correctCount / FINAL_EXAM.length) >= FINAL_PASS_THRESHOLD;

  let certId = null;
  if (passed) {
    const existing = db.prepare('SELECT id FROM certificates WHERE user_id = ?').get(req.session.userId);
    if (existing) {
      certId = existing.id;
    } else {
      certId = uuidv4();
      db.prepare('INSERT INTO certificates (id, user_id, final_score) VALUES (?,?,?)')
        .run(certId, req.session.userId, score);
    }
  }
  res.json({ score, passed, correctCount, total: FINAL_EXAM.length, certificateId: certId });
});

// ---------- Certificate PDF ----------
app.get('/api/certificate/:id', (req, res) => {
  const cert = db.prepare('SELECT * FROM certificates WHERE id = ?').get(req.params.id);
  if (!cert) return res.status(404).send('Certificate not found');
  const user = db.prepare('SELECT name FROM users WHERE id = ?').get(cert.user_id);

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="master-builder-certificate.pdf"`);

  const doc = new PDFDocument({ layout: 'landscape', size: 'A4', margin: 0 });
  doc.pipe(res);

  const W = doc.page.width, H = doc.page.height;
  doc.rect(0, 0, W, H).fill('#F2E8D6');
  doc.rect(24, 24, W - 48, H - 48).lineWidth(3).stroke('#122036');
  doc.rect(34, 34, W - 68, H - 68).lineWidth(1).stroke('#C1602E');

  doc.fillColor('#122036').fontSize(14).font('Helvetica-Bold')
    .text('MASTER BUILDER — INTERACTIVE COURSE', 0, 90, { align: 'center', characterSpacing: 2 });
  doc.fillColor('#C1602E').fontSize(12).font('Helvetica')
    .text('CERTIFICATE OF COMPLETION', 0, 115, { align: 'center', characterSpacing: 3 });

  doc.fillColor('#122036').fontSize(30).font('Helvetica-Bold')
    .text(user ? user.name : 'Course Graduate', 0, 175, { align: 'center' });

  doc.fillColor('#2A3245').fontSize(13).font('Helvetica')
    .text('has successfully completed all 22 modules and passed the final examination', 0, 225, { align: 'center' })
    .text('of the Master Builder Interactive Course', 0, 245, { align: 'center' });

  doc.fontSize(11).fillColor('#5B5648')
    .text(`Final exam score: ${cert.final_score}%`, 0, 285, { align: 'center' })
    .text(`Issued: ${new Date(cert.issued_at).toLocaleDateString()}`, 0, 302, { align: 'center' })
    .text(`Certificate ID: ${cert.id}`, 0, 319, { align: 'center' });

  doc.fontSize(9).fillColor('#9CA8BE')
    .text(`Verify at: /verify/${cert.id}`, 0, H - 60, { align: 'center' });

  doc.end();
});

app.get('/verify/:id', (req, res) => {
  const cert = db.prepare('SELECT c.*, u.name FROM certificates c JOIN users u ON u.id = c.user_id WHERE c.id = ?')
    .get(req.params.id);
  if (!cert) return res.status(404).send('<h1>Certificate not found</h1><p>This certificate ID does not exist in our records.</p>');
  res.send(`
    <html><body style="font-family:sans-serif;max-width:500px;margin:60px auto;text-align:center;">
    <h1>&#10003; Verified</h1>
    <p><strong>${cert.name}</strong> completed the Master Builder Interactive Course
    with a final exam score of <strong>${cert.final_score}%</strong>
    on ${new Date(cert.issued_at).toLocaleDateString()}.</p>
    <p style="color:#888;font-size:12px;">Certificate ID: ${cert.id}</p>
    </body></html>
  `);
});

// ---------- Frontend catch-all ----------
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => console.log(`Master Builder platform running on port ${PORT}`));
